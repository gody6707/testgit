<template>
<div class="ev-signup">
 This is the signup
</div>
</template>

<script>
export default {
  name: 'signup',
  data () {
    return {
    }
  }
}
</script>

<style lang="scss">



</style>
